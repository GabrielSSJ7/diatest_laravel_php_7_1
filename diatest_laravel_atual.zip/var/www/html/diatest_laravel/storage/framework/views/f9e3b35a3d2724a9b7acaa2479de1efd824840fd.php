<?php $__env->startSection('title', "Contato"); ?>

<?php $__env->startSection('content'); ?>




<!-- HOME -->
 <div id="home" style="    padding: 45px 0;" >


        <!-- container -->
        <div class="container">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <ul>
                    <li><?php echo session('success'); ?></li>
                </ul>
            </div>
        <?php endif; ?>
              <div class="section-title">
                      <h2 class="title">Contato</h2>
                      <div class="pull-right">
                        <div class="product-slick-dots-1 custom-dots"></div>
                      </div>
                    </div>
          <!-- home wrap -->

          <div id="contato-form" class="col-md-6">
            <form action="<?php echo e(url('sendMail')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                  <input type="text" name="nome" id="nome" placeholder="Nome" class="form-control" >
              </div>
              <div class="form-group">
                  <input type="text" name="sobrenome" id="sobrenome" placeholder="Sobrenome" class="form-control">
              </div>
              <div class="form-group">
                  <input type="text" name="email" id="email" placeholder="E-Mail" class="form-control">
              </div>
              <div class="form-group">
                  <input type="text" name="empresa" id="empresa" placeholder="Empresa" class="form-control">
              </div>
              <div class="form-group">
                  <input type="text" name="telefone" id="telefone" placeholder="Telefone" class="form-control">
              </div>
              <div class="form-group">
                  <input type="text" name="estado" id="estado" class="form-control" placeholder="Estado">
              </div>
              <div class="form-group">
                  <input type="text" name="cidade" id="cidade" class="form-control" placeholder="Cidade">
              </div>

              <div class="form-group">
                  <textarea type="text" name="duvida" id="duvida" class="form-control" placeholder="Qual sua dúvida / solicitação?" ></textarea>
              </div>

              <button class="primary-btn">Enviar</button>
            </form>
          </div>

          <div class="col-md-6" style="border-left: 1px solid lightgrey; height: 452px;">
              <h3>Endereço: </h3>
              <p>Diatest do Brasil Produtos de Medição Ltda</p>
              <p>Rua Ulisses Cruz, 1052 • 3 Andar • Cj. 6 • Tatuapé • São Paulo • (11) 2091-8811</p>

              <h3>E-Mail | Telefone</h3>

              <p>info@diatest.com.br</p>
                      <p>(11) 2091-8811</p>
          </div>

          <!-- /home wrap -->
        </div>
        <!-- /container -->
      </div>
      <!-- /HOME -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/diatest_laravel/resources/views//contato.blade.php ENDPATH**/ ?>