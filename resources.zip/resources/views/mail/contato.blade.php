<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contato do site</title>
</head>
<body>
<p><strong>Nome:</strong> {{ $name }}</p>
<p><strong>Sobrenome: </strong> {{$sobrenome}}</p>
<p><strong>E-mail: </strong> {{$email}}</p>
<p><strong>Empresa: </strong> {{$empresa}}</p>
<p><strong>Telefone: </strong> {{$telefone}}</p>
<p><strong>Estado: </strong> {{$estado}}</p>
<p><strong>Cidade: </strong> {{$cidade}}</p>
<p><strong>Dúvida: </strong>{{ $text }}</p>    
</body>
</html>